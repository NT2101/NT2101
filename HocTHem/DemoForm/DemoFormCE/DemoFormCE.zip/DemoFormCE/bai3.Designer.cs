﻿namespace DemoFormCE
{
    partial class bai3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lsb_Trai = new System.Windows.Forms.ListBox();
            this.lsb_Phai = new System.Windows.Forms.ListBox();
            this.btlthoat = new System.Windows.Forms.Button();
            this.btlreset = new System.Windows.Forms.Button();
            this.btlNhap = new System.Windows.Forms.Button();
            this.btlD = new System.Windows.Forms.Button();
            this.btlC = new System.Windows.Forms.Button();
            this.btlB = new System.Windows.Forms.Button();
            this.btlA = new System.Windows.Forms.Button();
            this.cbbht = new System.Windows.Forms.ComboBox();
            this.dtkA = new System.Windows.Forms.DateTimePicker();
            this.dtkB = new System.Windows.Forms.DateTimePicker();
            this.rtxtKetQua = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(121, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "DANH SÁCH THỂ THAO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(61, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Chọn họ tên";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(262, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(262, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "Danh sách đã chọn";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(61, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "Danh sách các môn";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(61, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 22);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kết quả";
            // 
            // lsb_Trai
            // 
            this.lsb_Trai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsb_Trai.FormattingEnabled = true;
            this.lsb_Trai.ItemHeight = 22;
            this.lsb_Trai.Items.AddRange(new object[] {
            "Bóng đá",
            "Bóng bàn",
            "Nhảy dù",
            "Bập bềnh"});
            this.lsb_Trai.Location = new System.Drawing.Point(64, 211);
            this.lsb_Trai.Name = "lsb_Trai";
            this.lsb_Trai.Size = new System.Drawing.Size(120, 92);
            this.lsb_Trai.TabIndex = 7;
            // 
            // lsb_Phai
            // 
            this.lsb_Phai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsb_Phai.ItemHeight = 22;
            this.lsb_Phai.Location = new System.Drawing.Point(265, 211);
            this.lsb_Phai.Name = "lsb_Phai";
            this.lsb_Phai.Size = new System.Drawing.Size(127, 92);
            this.lsb_Phai.TabIndex = 8;
            // 
            // btlthoat
            // 
            this.btlthoat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlthoat.Location = new System.Drawing.Point(280, 395);
            this.btlthoat.Name = "btlthoat";
            this.btlthoat.Size = new System.Drawing.Size(87, 33);
            this.btlthoat.TabIndex = 9;
            this.btlthoat.Text = "Thoát";
            this.btlthoat.UseVisualStyleBackColor = true;
            // 
            // btlreset
            // 
            this.btlreset.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlreset.Location = new System.Drawing.Point(280, 356);
            this.btlreset.Name = "btlreset";
            this.btlreset.Size = new System.Drawing.Size(87, 33);
            this.btlreset.TabIndex = 10;
            this.btlreset.Text = "Reset";
            this.btlreset.UseVisualStyleBackColor = true;
            this.btlreset.Click += new System.EventHandler(this.btlreset_Click);
            // 
            // btlNhap
            // 
            this.btlNhap.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlNhap.Location = new System.Drawing.Point(280, 312);
            this.btlNhap.Name = "btlNhap";
            this.btlNhap.Size = new System.Drawing.Size(87, 38);
            this.btlNhap.TabIndex = 11;
            this.btlNhap.Text = "Nhập";
            this.btlNhap.UseVisualStyleBackColor = true;
            this.btlNhap.Click += new System.EventHandler(this.btlNhap_Click);
            // 
            // btlD
            // 
            this.btlD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlD.Location = new System.Drawing.Point(201, 298);
            this.btlD.Name = "btlD";
            this.btlD.Size = new System.Drawing.Size(37, 23);
            this.btlD.TabIndex = 12;
            this.btlD.Text = ">>";
            this.btlD.UseVisualStyleBackColor = true;
            this.btlD.Click += new System.EventHandler(this.btlD_Click);
            // 
            // btlC
            // 
            this.btlC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlC.Location = new System.Drawing.Point(201, 269);
            this.btlC.Name = "btlC";
            this.btlC.Size = new System.Drawing.Size(37, 23);
            this.btlC.TabIndex = 13;
            this.btlC.Text = "<";
            this.btlC.UseVisualStyleBackColor = true;
            this.btlC.Click += new System.EventHandler(this.btlC_Click);
            // 
            // btlB
            // 
            this.btlB.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlB.Location = new System.Drawing.Point(201, 240);
            this.btlB.Name = "btlB";
            this.btlB.Size = new System.Drawing.Size(37, 23);
            this.btlB.TabIndex = 14;
            this.btlB.Text = ">>";
            this.btlB.UseVisualStyleBackColor = true;
            this.btlB.Click += new System.EventHandler(this.btlB_Click);
            // 
            // btlA
            // 
            this.btlA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlA.Location = new System.Drawing.Point(201, 211);
            this.btlA.Name = "btlA";
            this.btlA.Size = new System.Drawing.Size(37, 23);
            this.btlA.TabIndex = 15;
            this.btlA.Text = ">";
            this.btlA.UseVisualStyleBackColor = true;
            this.btlA.Click += new System.EventHandler(this.button7_Click);
            // 
            // cbbht
            // 
            this.cbbht.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbht.FormattingEnabled = true;
            this.cbbht.Items.AddRange(new object[] {
            "Nguyễn Văn A",
            "Nguyễn Văn B"});
            this.cbbht.Location = new System.Drawing.Point(184, 86);
            this.cbbht.Name = "cbbht";
            this.cbbht.Size = new System.Drawing.Size(151, 30);
            this.cbbht.TabIndex = 17;
            // 
            // dtkA
            // 
            this.dtkA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtkA.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtkA.Location = new System.Drawing.Point(110, 138);
            this.dtkA.Name = "dtkA";
            this.dtkA.Size = new System.Drawing.Size(128, 30);
            this.dtkA.TabIndex = 18;
            // 
            // dtkB
            // 
            this.dtkB.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtkB.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtkB.Location = new System.Drawing.Point(319, 138);
            this.dtkB.Name = "dtkB";
            this.dtkB.Size = new System.Drawing.Size(128, 30);
            this.dtkB.TabIndex = 19;
            // 
            // rtxtKetQua
            // 
            this.rtxtKetQua.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtKetQua.Location = new System.Drawing.Point(64, 341);
            this.rtxtKetQua.Name = "rtxtKetQua";
            this.rtxtKetQua.Size = new System.Drawing.Size(163, 97);
            this.rtxtKetQua.TabIndex = 20;
            this.rtxtKetQua.Text = "";
            // 
            // bai3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 502);
            this.Controls.Add(this.rtxtKetQua);
            this.Controls.Add(this.dtkB);
            this.Controls.Add(this.dtkA);
            this.Controls.Add(this.cbbht);
            this.Controls.Add(this.btlA);
            this.Controls.Add(this.btlB);
            this.Controls.Add(this.btlC);
            this.Controls.Add(this.btlD);
            this.Controls.Add(this.btlNhap);
            this.Controls.Add(this.btlreset);
            this.Controls.Add(this.btlthoat);
            this.Controls.Add(this.lsb_Phai);
            this.Controls.Add(this.lsb_Trai);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "bai3";
            this.Text = "bai3";
            this.Load += new System.EventHandler(this.bai3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox lsb_Trai;
        private System.Windows.Forms.ListBox lsb_Phai;
        private System.Windows.Forms.Button btlthoat;
        private System.Windows.Forms.Button btlreset;
        private System.Windows.Forms.Button btlNhap;
        private System.Windows.Forms.Button btlD;
        private System.Windows.Forms.Button btlC;
        private System.Windows.Forms.Button btlB;
        private System.Windows.Forms.Button btlA;
        private System.Windows.Forms.ComboBox cbbht;
        private System.Windows.Forms.DateTimePicker dtkA;
        private System.Windows.Forms.DateTimePicker dtkB;
        private System.Windows.Forms.RichTextBox rtxtKetQua;
    }
}